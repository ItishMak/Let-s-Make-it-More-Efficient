Group-32 CSE 535 Mobile Computing/Final-Project


Project-Title: Let's Make it More Efficient


Environment Instructions:
compileSdkVersion 28
    defaultConfig {
        applicationId "com.example.group32finalproject"
        minSdkVersion 15
        targetSdkVersion 28
        versionCode 1
        versionName "1.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }


Description of Files:

there are 4 folders: 
1. Project Source Code. 
	1. Android Code: Contains all java source files to run the application
	2. Back_end Code: Contains the PHP scripts to run the back-end operations.
		Back-End PHP code (contains two Files)
		1.divide.php
		2.test.php
	3. 'app_debug.apk' (to install apk on the mobile device).
2. Dataset folder contains the Credit-german dataset.
3. To intall WEKA dependendices in the android. Make sure to add the 'WekaSTRIPPED.jar' library as dependency in your android application.
4. REPORT folder contains the report.


To execute/install the application you just install app_debug.apk in your android device.

To execute file in android studio:
1. Unzip Group32FinalProject.zip file present in Android-code Folder.
2. Now Import 'Group32FinalProject' project to your android studio.
3. Sync the Gradle to install dependencies.(Make sure to install WEKA library to run the application)
4. Now run the application by selecting any virtual device/connecting to real-device through USB.
5. Once the app is runned succesfully, then the following activites should be done to explore the application.
6. To install application in your mobile device. Install 'app_debug.apk' in your android device and Make sure that dataset.arff is stored locally on your mobile-device.


Functionalities of the Mobile Application:

1. Start Activity:
	1.On Launching the app, "Let's make it more Efficient" screen is launched. In this user is asked to enter the split ratio of a dataset. When the user enters some value and click 'Divide' button dataset is divide to the specified ratio.

	2.Also, down there is an 'Upload' functionality which allows the user to Upload the Database to the server. And also training data is uploaded to the server.
	3.In Back-end Local fog server (Apache HTTP server) is used.

	4.WEKA library is used to integrate Machine-learning Models in Android such that by executing the Weka commands on the Local server machine-learning model is trained using the uploaded training set.

	5.Bottom there is a Spinner containing 4 Machine Learning Models such that after selecting any of the Algorithms by Clicking on the 'Confirm Algorithm' button. User is directed to other activity.

	6.Machine Learning Models used: Support Vector Machine, Decision Tree, Naive Bayes and Random Forest.


2. Machine-Learning Model Traning Acitivity

	1.Based on the Model selected by the user in first activity, in this acitivity user is prompted to enter the parameter values required to train corresponding models.

	2.After entering the parameter values by the user. By clicking the 'train' button, model is trained in back-end fog server using training set uploaded in previous activity and created the trained_model in local_server. 'train' button not only creates the model on the server but also download the trained model in local storage device. i.e. Training the model in back-end server and testing the test-data in the local-device is the unique-module introduced in our project. 

	3.Now by clicking on the 'test' button. Trained model in local device is tested locally on the mobile-device and displays the accuracies and various statistical results down the same activity.

3.On Options Menu
	On options Menu contains an option named as 'Accuracies' by clicking on these button, it displays the results for all the executed models in the File.

	





